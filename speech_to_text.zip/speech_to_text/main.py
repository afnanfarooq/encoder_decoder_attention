import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from torch.utils.data.dataset import random_split
import sys
sys.path.append('/Home/Downloads/project42/speech_to_text/utils')
import text_preprocessing
from encoder_decoder import EncoderLSTM, DecoderLSTM

# Example usage:
input_features = 12
hidden_size = 4736
output_features = 4736
batch_size = 2
sequence_length = 4736

input_data = np.array(create_data.amplitude_points_list[:4])
input_data = torch.tensor(input_data, dtype=torch.float32)

output_data = ntext_preprocessing.one_hot_encoded
output_data = torch.tensor(output_data[:4], dtype=torch.long)
dataset = TensorDataset(input_data, output_data)

train_ratio = 0.5
val_size = int(len(dataset) * 0.5)
train_size = len(dataset) - int(len(dataset) * train_ratio)
train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size)



# Create the encoder and decoder models
encoder_model = EncoderLSTM(input_features, hidden_size)
decoder_model = DecoderLSTM(output_features, hidden_size)

# Define the loss function and optimizer
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(list(encoder_model.parameters()) + list(decoder_model.parameters()), lr=0.001)

# Training loop
num_epochs = 1

for epoch in range(num_epochs):
    encoder_model.train()
    decoder_model.train()
    print(f"Epoch {epoch + 1}")
    total_loss = 0

    for batch_input, batch_output in train_loader:
        optimizer.zero_grad()

        encoder_output, encoder_hidden = encoder_model(batch_input)
        predicted_output = decoder_model(batch_output, encoder_hidden)

        loss = criterion(predicted_output, batch_output)

        loss.backward()
        nn.utils.clip_grad_norm_(list(encoder_model.parameters()) + list(decoder_model.parameters()), max_norm=1.0)

        optimizer.step()

        total_loss += loss.item()

    print(f"Training Loss: {total_loss / len(train_loader)}")

    # Validation loop
    encoder_model.eval()
    decoder_model.eval()
    val_loss = 0

    with torch.no_grad():
        for batch_input, batch_output in val_loader:
            encoder_output, encoder_hidden = encoder_model(batch_input)
            predicted_output = decoder_model(batch_output, encoder_hidden)

            val_loss += criterion(predicted_output, batch_output).item()

    print(f"Validation Loss: {val_loss / len(val_loader)}")

