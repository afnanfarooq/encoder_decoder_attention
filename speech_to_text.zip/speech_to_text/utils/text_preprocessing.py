import os
import string
import re
from sklearn.preprocessing import MultiLabelBinarizer
import torch
import numpy as np

class TextProcessor:
    def __init__(self, folder_path):
        self.folder_path = folder_path

    def preprocess_strings(self, string_list):
        processed_strings = []

        for text in string_list:
            # Step 1: Lowercasing
            text = text.lower()

            # Step 2: Tokenization (Split into words)
            tokens = text.split()

            # Step 3: Removing Punctuation
            translator = str.maketrans('', '', string.punctuation)
            tokens = [token.translate(translator) for token in tokens]

            # Step 4: Removing Numbers
            tokens = [re.sub(r'\d+', '', token) for token in tokens]

            # Step 5: Removing Extra Spaces
            tokens = [token.strip() for token in tokens if token.strip()]

            # Combine the preprocessed tokens back into a string
            processed_text = ' '.join(tokens)
            processed_strings.append(processed_text)

        return processed_strings

    def one_hot_encoding(self, string_list):
        # Create a vocabulary of unique words
        vocabulary = set(' '.join(string_list).split())

        # Convert the vocabulary to a sorted list
        vocab_list = sorted(list(vocabulary))

        # Tokenize the strings and create a list of lists of tokens
        tokenized_texts = [text.split() for text in string_list]

        # Create a MultiLabelBinarizer object to perform multi-output one-hot encoding
        mlb = MultiLabelBinarizer(classes=vocab_list)
        one_hot_encoded = mlb.fit_transform(tokenized_texts)

        return one_hot_encoded, vocab_list

    def read_text_files_in_folder(self):
        file_contents_list = []

        # List all files in the folder
        files = os.listdir(self.folder_path)

        # Iterate through each file and read its contents
        for file_name in files:
            file_path = os.path.join(self.folder_path, file_name)
            if os.path.isfile(file_path) and file_name.endswith('.txt'):
                with open(file_path, 'r') as file:
                    content = file.read()
                    file_contents_list.append(content)

        return file_contents_list


