import os
import wave
import numpy as np
import librosa
import soundfile as sf
import torch

class AmplitudePointsGenerator:
    def __init__(self, folder_path, sublist_length=12):
        self.folder_path = folder_path
        self.sublist_length = sublist_length

    def get_amplitude_points(self, wav_file):
        x, _ = librosa.load(wav_file, sr=16000)
        tmp_wav_file = 'tmp.wav'
        sf.write(tmp_wav_file, x, 16000)

        try:
            with wave.open(tmp_wav_file, 'rb') as wf:
                frames = wf.readframes(-1)
                channels = wf.getnchannels()
                sample_width = wf.getsampwidth()
                frame_rate = wf.getframerate()

            audio_np = np.frombuffer(frames, dtype=np.int16)
            time_points = np.linspace(0, len(audio_np) / frame_rate, num=len(audio_np))

            return time_points, audio_np
        except wave.Error as e:
            print(f"Error while processing {wav_file}: {e}")
            return None, None
        finally:
            os.remove(tmp_wav_file)

    def divide_into_sublists(self, arr):
        # Pad or truncate the array to have a length that's a multiple of sublist_length
        padding_length = (self.sublist_length - len(arr) % self.sublist_length) % self.sublist_length
        arr = np.pad(arr, (0, padding_length), mode='constant')
        return [arr[i:i + self.sublist_length] for i in range(0, len(arr), self.sublist_length)]

    def generate_amplitude_points(self):
        if not os.path.isdir(self.folder_path):
            print(f"Error: {self.folder_path} is not a valid directory.")
            return None

        wav_files = [file for file in os.listdir(self.folder_path) if file.lower().endswith(".wav")]

        all_amplitude_points = []  # Container for all amplitude points
        max_num_sublists = 0

        for wav_file in wav_files:
            wav_path = os.path.join(self.folder_path, wav_file)
            time_points, audio_np = self.get_amplitude_points(wav_path)
            if time_points is not None and audio_np is not None:
                # Divide the amplitude points into sublists
                sublists = self.divide_into_sublists(audio_np)
                all_amplitude_points.append(sublists)
                max_num_sublists = max(max_num_sublists, len(sublists))

        # Pad or truncate each sublist to ensure they all have the same number of sublists
        for amplitude_points in all_amplitude_points:
            while len(amplitude_points) < max_num_sublists:
                amplitude_points.append(np.zeros(self.sublist_length))

        print(f"Amplitude points generated for {len(wav_files)} .wav files.")
        return all_amplitude_points

if __name__ == "__main__":
    folder_path = "/home/hamza/Downloads/project42/sentences/audios"
    sublist_length = 12

    amplitude_points_generator = AmplitudePointsGenerator(folder_path, sublist_length)
    amplitude_points_list = amplitude_points_generator.generate_amplitude_points()

    # Now amplitude_points_list contains the amplitude points for each .wav file as a list of lists of sublists.
    # Each sublist contains 12 points, and each list corresponds to a .wav file.

    print(len(amplitude_points_list[1]))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    tensor_list = [torch.tensor(sublist, device=device) for sublist in amplitude_points_list]
    amplitude_points_tensor = torch.stack(tensor_list)
    # print(amplitude_points_tensor)

