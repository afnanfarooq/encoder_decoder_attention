import torch
import torch.nn as nn
import encoder
class DecoderLSTM(nn.Module):
    def __init__(self, output_features, hidden_size):
        super(DecoderLSTM, self).__init__()

        self.decoder_lstm = nn.LSTM(
            input_size=output_features,
            hidden_size=hidden_size,
            batch_first=True
        )

        self.output_layer = nn.Linear(hidden_size, output_features)

    def forward(self, x, encoder_output):
        decoder_hidden = encoder_output

        decoder_outputs, _ = self.decoder_lstm(x, decoder_hidden)

        output_sequence = self.output_layer(decoder_outputs)

        return output_sequence