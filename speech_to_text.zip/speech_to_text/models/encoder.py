import torch
import torch.nn as nn
class EncoderLSTM(nn.Module):
    def __init__(self, input_features, hidden_size):
        super(EncoderLSTM, self).__init__()

        self.encoder_lstm = nn.LSTM(
            input_size=input_features,
            hidden_size=hidden_size,
            batch_first=True
        )

    def forward(self, x):
        encoder_output, encoder_hidden = self.encoder_lstm(x)
        return encoder_output, encoder_hidden
