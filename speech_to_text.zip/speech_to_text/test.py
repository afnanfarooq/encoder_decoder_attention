class Validator:
    def __init__(self, model, val_loader, criterion):
        self.model = model
        self.val_loader = val_loader
        self.criterion = criterion

    def validate(self):
        self.model.eval()
        val_loss = 0

        with torch.no_grad():
            for batch_input, batch_output in self.val_loader:
                predicted_output = self.model(batch_input)
                val_loss += self.criterion(predicted_output, batch_output).item()

        print(f"Validation Loss: {val_loss / len(self.val_loader)}")

