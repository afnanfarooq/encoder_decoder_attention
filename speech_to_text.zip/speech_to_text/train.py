class Trainer:
    def __init__(self, model, train_loader, val_loader, criterion, optimizer):
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.criterion = criterion
        self.optimizer = optimizer

    def train(self, num_epochs):
        for epoch in range(num_epochs):
            self.model.train()
            total_loss = 0

            for batch_input, batch_output in self.train_loader:
                self.optimizer.zero_grad()

                predicted_output = self.model(batch_input)

                loss = self.criterion(predicted_output, batch_output)

                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

                self.optimizer.step()

                total_loss += loss.item()

            print(f"Epoch {epoch+1}, Training Loss: {total_loss / len(self.train_loader)}")
